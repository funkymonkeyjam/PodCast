# Installer

The installer is built with WiX Toolset 6.0.2.

- `AirFlash-X.Y.Z.msi` is a standalone per-machine installer.
- The MSI installs the self-contained `AirFlash.exe` under `Program Files\AirFlash`.
- The standard installer UI lets the user change the install directory and optionally creates desktop and Start menu shortcuts. Both shortcut options are enabled by default.
- The installed package appears in Windows Apps and Features and does not require a separate Setup.exe, .NET runtime, Rust runtime, or VC++ Redistributable.
- New installations require an x64 system and Windows build 17763 or newer. The installer reads `CurrentBuildNumber` from the 64-bit registry view; maintenance and removal remain available for installed products.

Windows 10 execution is pending affected-user verification. See [compatibility diagnostics and acceptance](../docs/WINDOWS-COMPATIBILITY.md).

Build the release outputs with:

```powershell
pwsh scripts/build.ps1
```

The release directory contains only `AirFlash.exe` and `AirFlash-X.Y.Z.msi`.
The filename uses the MSI ProductVersion read from the published EXE, for example `AirFlash-0.3.0.msi`.

For a standalone MSI build, `scripts/build-installer.ps1 -DotnetPath <host>` selects an explicit .NET executable (relative paths are rooted at the repository). Both explicit and default hosts are checked and invoked from `desktop`, using `desktop/global.json`'s SDK policy. SDK failure occurs before the output directory is created. The release build passes its already selected host to the installer.

Each release build reserves an increasing three-field version in `artifacts/release-version.txt` before publishing; preserve this record. MSI takes its version from the published EXE. Old products sharing the UpgradeCode are removed inside the install transaction. Repair reinstalls files, and installing over a portable AirFlash.exe replaces that file only. User settings and pairing data survive uninstall. Close AirFlash when Windows Installer requests it; locked files may require a restart.
Installation, repair and removal request AirFlash to exit and verify that it has stopped before removing older products or replacing files. If shutdown fails, the MSI aborts with a retry message.

using System.Runtime.InteropServices;
using AirFlash.App.Services;
using AirFlash.App.Verification;
using AirFlash.Core;
namespace AirFlash.App;

internal static class Program
{
    internal static bool IsDiagnostic(string[] args) => args.Any(a => a.EndsWith("-check", StringComparison.Ordinal)
        || a is "--ui-smoke" or "--tray-smoke" or "--ui-perf" or "--discovery-perf");
    [STAThread]
    public static int Main(string[] args)
    {
        if (args.Contains("--quit"))
        {
            try
            {
                var instance = new SingleInstance();
                try { return instance.IsOwner || instance.RequestQuitAsync().GetAwaiter().GetResult() ? 0 : 1; }
                finally { instance.DisposeAsync().AsTask().GetAwaiter().GetResult(); }
            }
            catch (Exception error) { AppPaths.Log($"Graceful quit failed: {error}"); return 1; }
        }
        if (IsDiagnostic(args))
            AppPaths.DataDirectory = Path.Combine(Path.GetTempPath(), "PodCast-diagnostics", Guid.NewGuid().ToString("N"));
        // Also works when the WPF resource dictionary or localization cannot initialize.
        AppDomain.CurrentDomain.UnhandledException += (_, e) => AppPaths.Log($"Fatal stage=unhandled {e.ExceptionObject}");
        TaskScheduler.UnobservedTaskException += (_, e) => AppPaths.Log($"Background task failed {e.Exception}");
        var stage = "platform";
        try
        {
            if (args.Contains("--ui-smoke") || args.Contains("--tray-smoke"))
                AppPaths.DataDirectory = Path.Combine(Path.GetDirectoryName(UiSmoke.ReportPath(args))!, "isolated-data");
            else if (IsDiagnostic(args))
            {
                var index = Array.FindIndex(args, arg => arg is "--output" or "--self-check-output");
                if (index >= 0 && index + 1 < args.Length)
                    AppPaths.DataDirectory = Path.Combine(Path.GetDirectoryName(Path.GetFullPath(args[index + 1]))!, args.Contains("--compat-check") ? "compat-logs" : "isolated-data");
            }
            AppPaths.Log($"Startup stage={stage} version={AppPaths.Version} os={Environment.OSVersion.Version} architecture={RuntimeInformation.ProcessArchitecture}");
            if (!WindowsCapabilities.Current.Supported) throw new PlatformNotSupportedException(WindowsCompatibility.Requirement);
            stage = "wpf-resources";
            var app = new App();
            app.InitializeComponent();
            AppPaths.Log($"Startup stage={stage} ready");
            return app.Run();
        }
        catch (Exception error)
        {
            AppPaths.Log($"Startup stage={stage} failed {error}");
            try { App.WriteOutput(args, new { ok = false, stage, error = error.ToString(), hresult = $"0x{error.HResult:X8}" }); }
            catch (Exception reportError) { AppPaths.Log($"Diagnostic output failed: {reportError.Message}"); }
            if (!IsDiagnostic(args))
                MessageBox(IntPtr.Zero, $"{error.Message}\n\nLogs: {AppPaths.LogDirectory}", "PodCast startup failed", 0x10);
            return 1;
        }
    }

    [DllImport("user32.dll", EntryPoint = "MessageBoxW", CharSet = CharSet.Unicode)]
    private static extern int MessageBox(IntPtr owner, string message, string caption, uint type);
}
